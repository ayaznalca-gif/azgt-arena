function updateClock(){
  const el=document.getElementById("clock");
  if(!el) return;
  el.textContent=new Intl.DateTimeFormat("tr-TR",{hour:"2-digit",minute:"2-digit"}).format(new Date());
}
updateClock();
setInterval(updateClock,30000);

document.querySelectorAll("nav a").forEach(link=>{
  link.addEventListener("click",()=>{
    document.querySelectorAll("nav a").forEach(x=>x.classList.remove("active"));
    link.classList.add("active");
  });
});
