# AZGT ARENA

Modern futbol portalının ilk sürümü.

## Dosyalar
- `index.html` → sayfanın yapısı
- `style.css` → AZGT ARENA tasarımı
- `script.js` → saat ve temel etkileşimler

## GitHub Pages
Bu dosyaları GitHub repository'sinin ana dizinine yükleyip **Settings → Pages** bölümünden yayınlayabilirsin. GitHub Pages statik HTML/CSS/JavaScript dosyalarını doğrudan yayınlayabilir.

## Sonraki aşama
Canlı futbol verileri için bir futbol veri API'si bağlanacak. API anahtarı herkese açık `script.js` içine yazılmayacak; güvenli bir sunucu/serverless katmanı kullanılacak.
